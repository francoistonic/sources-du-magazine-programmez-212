# Web Components
Understanding the 4 standards behind Web Components:
-> 4 examples of how each native API is used.
-> 1 example of a Web Component using the 4 APIs.

Examples are implemented using VanillaJS.
Stay tuned for examples using Polymer 2.0 and Polymer 3.0 ^^
